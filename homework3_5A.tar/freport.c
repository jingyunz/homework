#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <time.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h> 
#include <unistd.h>
#include <pwd.h>

#define PATH_MAX_LEN 150

/*
void printLevel(int level)
{
	for(int i=0; i<level; i++)
	{
		printf("|----");
	}
}
*/

void listDir(int size, int period, char *abpath, int level, int *timeCount)
{
	DIR *dp;
	struct dirent *ptr;    
	char infile[PATH_MAX_LEN], temp[PATH_MAX_LEN];
	time_t t, now;
	struct stat fstat;


	time(&now);

	if(period==0 && size==0)
	{
		dp=opendir(abpath);
		while((ptr=readdir(dp))!=NULL)
		{

			//跳过'.'和'..'两个目录
			if(ptr->d_name[0] == '.')
				continue;
			strcpy(temp,abpath);
			strcat(temp,"/");
			strcat(temp,ptr->d_name);
			memset(infile, 0, PATH_MAX_LEN);
			sprintf(infile,"%s",temp);
			stat(infile, &fstat);
			t=fstat.st_atime;

			/*
			if(level != -1)
			{
				printLevel(level);
			}
			*/
			printf("<%s>\n\tLast access:%s",infile,ctime(&t) ); 
			time_t tmdf=fstat.st_mtime;
			printf("\tLast modified:%s",ctime(&tmdf) ); 
			printf("\tUser ID is: %u\n\tgroup ID is: %u\n", 
					fstat.st_uid, fstat.st_gid);
			if (S_ISREG(fstat.st_mode))
			{    
			//	printf("\t普通文件.\n");

				if(fstat.st_size!=0)
					printf("\tSize:%d Bytes\n",(int)fstat.st_size);
				if(difftime(now,t)>=365*24*3600)
					printf("\tLong time unused.\n");
				else
					printf("\tHave been accessed in %ld days.\n", (long)(difftime(now, t)+3600*24-1)/3600/24);
				if(fstat.st_size>=100000)
					printf("\tLarge-scale.\n");
				else if(fstat.st_size<=100&&fstat.st_size>0)
					printf("\tSmall-scale.\n");
				else if(fstat.st_size>0)
					printf("\tNormal-scale.\n");

				/*
				   fd = open(temp, O_RDWR);
				   printf("a:%d\n",fd);
				   close(fd);
				   */

				printf("\n");

			}
			else if (S_ISDIR(fstat.st_mode))
			{
				printf("该目录下的文件信息:\n");
				/*
				if(level != -1)
				{
					printLevel(level);
				}
				*/

				printf("\n");
				listDir(size, period, infile, level+1, timeCount);
			}
		}
		closedir(dp);
	}
	else
	{
		if(size!=0)
		{
			if(level == 0)
			{
				printf("files exceed %d bytes:\n", size);
			}
			int num1=0;
			dp=opendir(abpath);
			while((ptr=readdir(dp))!=NULL)
			{

				//跳过'.'和'..'两个目录
				if(ptr->d_name[0] == '.')
					continue;
				strcpy(temp,abpath);
				strcat(temp,"/");
				strcat(temp,ptr->d_name);
				sprintf(infile,"%s",temp);
				stat(infile, &fstat);
				if (S_ISREG(fstat.st_mode))
				{    
					if(fstat.st_size>=size)
					{
						num1++;
						t=fstat.st_atime;
						printf("<%s>\n",temp); 
					}
				}
				else if(S_ISDIR(fstat.st_mode))
				{
					listDir(size, period, infile, level+1, timeCount);
				}

			}
			closedir(dp);
		}
		if(period!=0)
		{
			if(level == 0 && timeCount == NULL)
			{
				printf("files used in %d days: \n", period);
			}
			int num2=0;
			dp=opendir(abpath);
			while((ptr=readdir(dp))!=NULL)
			{
				//跳过'.'和'..'两个目录
				if(ptr->d_name[0] == '.')
					continue;
				strcpy(temp,abpath);
				strcat(temp,"/");
				strcat(temp,ptr->d_name);
				sprintf(infile,"%s",temp);
				stat(infile, &fstat);
				t=fstat.st_atime;
				if (S_ISREG(fstat.st_mode))
				{  
					if(difftime(now,t)<period*24*3600)
					{
						num2++;
						stat(infile, &fstat);
						t=fstat.st_atime;
						if(timeCount == NULL)
						{
							printf("<%s>\n",temp); 
						}
					}
				}
				else if(S_ISDIR(fstat.st_mode))
				{
					listDir(size, period, infile, level+1, timeCount);
				}
			}
			if(timeCount != NULL)
			{
				*timeCount += num2;
				// printf("I reach here %d!\n", *timeCount);
			}
			closedir(dp);
		}
	}
}

int main(int argc, char * argv[])
{
	int size=0,period=0;
	/*
	   int fd;
	   struct flock lock; 
	   lock.l_type = F_WRLCK;
	   */

	int isCheckUser = 0;

	if(argc < 2)
	{
		printf("usage: freport [options] pathname\n");
		exit(1);
	}
	else if(argc == 2)
	{
		size=0;
		period = 0;
		if(opendir(argv[argc-1]) == NULL)
		{
			printf("ERROR: specified path '%s' does exists.\n", argv[argc-1]);
			exit(1);
		}
	}
	else
	{
		int ch;
		while( (ch=getopt(argc,argv,"s:t:h:c:")) !=-1)
		{
			switch(ch)
			{
				case 's': // size
					sscanf(optarg,"%d",&size);
					break;
				case 't': // period
					sscanf(optarg,"%d",&period);
					break;
				case 'c':
					isCheckUser = 1;	
					period = 30;
					break;
				case 'h': // help
					printf("usage: freport [options] pathname|username\n");
					printf("options:\n");
					printf("\t-s size:\tlist files whose length is beyond that you specified.\n");
					printf("\t-t days:\tlist files that has not been accessed more than the days that you specified.\n");
					printf("\t-c:\tAnounce user who has not operate for 30 days. the pathname should be the home path for the user\n");
					printf("\t-h:\thelp.\n");
					exit(0);
				default:
					break;
			}

		}    
	}

	char abpath[PATH_MAX_LEN];

	if(isCheckUser)
	{
		char tmp[PATH_MAX_LEN];
		sprintf(tmp, "/home/%s", argv[argc-1]);
		realpath(tmp, abpath);

		int filesAcc30Days = 0;
		listDir(size, period, abpath, 0, &filesAcc30Days);
		char msg[100] = "You have not access any file in you home directory for more than 30 days";

		if(filesAcc30Days == 0)
		{
			printf("User \'%s\' has not access any file in his/her home directory for more than 30 days\n", 
					argv[argc-1]);
			printf("A message has been send to him/her\n");
			char cmd[300];
			memset(cmd, 0, sizeof(cmd));
			sprintf(cmd, "echo \"%s\" | write %s\n", msg, argv[argc-1]);
			// printf("%s\n", cmd);
			system(cmd);
		}
	}
	else
	{
		realpath(argv[argc-1], abpath);
		listDir(size, period, abpath, 0, NULL);
	}

	return 0;
}

