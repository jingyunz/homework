
int wsum(int* ball,int pos);
int cmp1(int * ball);
int cmp2(int * ball,int big,int small,char mode,int *err);
int cmp3(int * ball,int err,char mode,char w);
