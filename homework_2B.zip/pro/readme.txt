
input.txt  //输入文件（12个数字代表12个小球的重量，0代表轻的，1代表重的，如111111111011）
output.txt //输出结果（example:
                               the error ball is:9
                               It is light         ）
answer.txt //正确输出结果


运行步骤：
make clean //清理项目
make   //编译文件
./selectball  //运行程序
make test //检测运行结果是否正确
